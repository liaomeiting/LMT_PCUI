/********************************* SKYCODE *************************************
* Copyright (c) 2014-2016, ����˼�����Լ������޹�˾������������Ӽ������޹�˾��
* All rights reserved.
*
* �ļ���   ��stm_spi.h    
* ����     �� �˳���������spi��
*           
*
* ��ǰ�汾 ��V1.0
* ��    �� ��SKYCODE2013
* ������� ��2016-09-24
* �޸����� ��
*						                          	
*******************************************************************************/
extern void LCD_CS_0(void);
extern void LCD_CS_1(void);

#include "stm_spi.h"
#include "sysio.h"
#include "S10.h"
#include <stdarg.h>

#define _Time    1         //��ʱʱ�� us


#define _CPOL     0
#define _CPHA     0


#define SPI_SCK PAout(0)	//SCL  ʱ��

#define SPI_CSX PBout(6)	//CSX  ʹ��Ƭѡ
#define SPI_DCX PBout(0)	//DCX  д����/дָ��

#define SPI_SDI PAout(3)	//SDI  ����
#define SPI_RSDI PAin(3)	//SDO  ������


//#define SPI_SDI PBout(5)	//SDI  ����
//#define SPI_RSDI PBin(4)	//SDO  ������

//#define SDA_IN()  {GPIOB->MODER&=~(3<<(5*2));GPIOB->MODER|=0<<5*2;}//PA3����ģʽ
//#define SDA_OUT() {GPIOB->MODER&=~(3<<(5*2));GPIOB->MODER|=1<<5*2;} //PA3���ģʽ

//#define SDA_IN()  {GPIOB->MODER|=0<<5*2;}//PA3����ģʽ
//#define SDA_OUT() {GPIOB->MODER|=1<<5*2;} //PA3���ģʽ





void SPI_Send_Dat(unsigned char dat);
unsigned char SPI_Receiver_Dat(void);


void SPI_delay(void)
{
	
//	Delay_us(_Time);
   uint16_t i=0;
   while(i) 
   { 
     i--; 
   }  
}

/************************************************
        �˿ڷ�������  �������ʼ��
************************************************/
void Spi_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA|RCC_AHB1Periph_GPIOB, ENABLE); 
    
    //CSX  ʹ��Ƭѡ
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;	
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;   
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; 
    GPIO_Init(GPIOB, &GPIO_InitStructure);	 
    
    //DCX  дָ�� ���� д����
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;	
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;   
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; 
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    //SCL ʱ��
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;	
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;   
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; 
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    //SDI ����
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;   
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);




//	      //SDI ����
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;	
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;   
//	GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
//	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; 
//	GPIO_Init(GPIOA, &GPIO_InitStructure);	
//	GPIO_ResetBits(GPIOA, GPIO_Pin_3);

	
    SPI_SDI=0;
    SPI_CSX=1;
    SPI_DCX=0;
    #if _CPOL==0
    SPI_SCK=0;
    #else
    SPI_SCK=1;
    #endif
}

void Spi_SDI_Read(void)
{
	 GPIO_InitTypeDef GPIO_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;   
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; 
	GPIO_Init(GPIOA, &GPIO_InitStructure);	
	GPIO_ResetBits(GPIOA, GPIO_Pin_3);
	
//		GPIOB->MODER&=~(3<<(5*2));GPIOB->MODER|=0<<5*2;
}


void Spi_SDI_Write()//IO�л�Ϊ���ģʽ
{
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;   
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	
//		GPIOB->MODER&=~(3<<(5*2));GPIOB->MODER|=1<<5*2;
//    
//    SPI_SDI=0;
}




void SPI_Write1(unsigned char cmd, unsigned char data)
{
    SPI_CSX=0;
    
    SPI_DCX=0;
    SPI_delay();
    SPI_Send_Dat(cmd);
    
    SPI_DCX=1;
    SPI_delay();
    SPI_Send_Dat(data);
    
    SPI_CSX=1;
    SPI_delay();
//    SPI_delay();
}


void SPI_cmd1(unsigned char cmd)
{
	SPI_CSX=0;
	SPI_SCK=0;//_nop_(); _nop_();_nop_();_nop_();
	SPI_SDI=0;
	SPI_SCK=1;//_nop_();_nop_();_nop_();_nop_();
	SPI_delay();
	SPI_Send_Dat(cmd);
	
	SPI_CSX=1;
}

void SPI_data1(unsigned char data)
{
	SPI_CSX=0;
	SPI_SCK=0;//_nop_(); _nop_();_nop_();_nop_();
	SPI_SDI=1;
	SPI_SCK=1;//_nop_();_nop_();_nop_();_nop_();
	SPI_delay();
	SPI_Send_Dat(data);
	SPI_CSX=1;
}


static uint8_t spi_pack_data[260];
void SPI_SendX(unsigned char cmd, unsigned char data,...)
{
    va_list param_list;
    int in_data;
    unsigned int len=0,i;
    
    va_start(param_list, data);
    
    spi_pack_data[len++] = data;
    
    while(1)
    {
        in_data = va_arg(param_list, int);
        if(in_data == -1)break;
        spi_pack_data[len++] = in_data;
    }
 
    if(len>256)return; 
	
		
	  SPI_Write_cmd(cmd);	
		
		SPI_DCX=1;
    for(i=0; i<len; i++)
    {
		 SPI_CSX=0;
     SPI_delay();
     SPI_Send_Dat(spi_pack_data[i]);  
		 SPI_CSX=1;
    }
    SPI_delay(); 
    
   
		
    va_end(param_list);	

}




unsigned char SPI_Read_Pg0(unsigned char cmd)
{
	unsigned char data;
    
    SPI_CSX=0;SPI_delay();
    
    SPI_DCX=0;
//	SPI_Send_Dat(0xF1);
	SPI_delay();
    SPI_Send_Dat(cmd);
    	
	SPI_SDI=0;
	
	Spi_SDI_Read();
	
//	SPI_SCK=0;
//	SPI_delay();
//	SPI_SCK=1;
//	SPI_delay();
   
    SPI_DCX=0;	
    data = SPI_Receiver_Dat();
    SPI_CSX=1;
    SPI_delay();

	Spi_SDI_Write();
	
    SPI_delay();	
    return data;
}

unsigned char SPI_Read(unsigned char cmd)
{
	unsigned char data;
    
	
	
//  SPI_CSX=0;
//	SPI_delay();
//	SPI_SCK=0;
//	SPI_delay();
//	SPI_SDI=0;
//	SPI_delay();
//	SPI_SCK=1;
//	SPI_Send_Dat(0xC4);
////  SPI_CSX=1;
////	
////	
////  SPI_CSX=0;
//	SPI_delay();
//	SPI_SCK=0;
//	SPI_delay();
//	SPI_SDI=1;
//	SPI_delay();
//	SPI_SCK=1;
//	SPI_Send_Dat(0x01);
//  SPI_CSX=1;
	
	
	
  SPI_CSX=0;
	SPI_delay();
	SPI_SCK=0;
	SPI_delay();
	SPI_SDI=0;
	SPI_delay();
	SPI_SCK=1;
	SPI_Send_Dat(0x47);
  SPI_CSX=1;
	
	
	
  SPI_CSX=0;
	SPI_delay();
	SPI_SCK=0;
	SPI_delay();
	SPI_SDI=0;
	SPI_delay();
	SPI_SCK=1;
  SPI_Send_Dat(cmd);

	SPI_SCK=0;
	SPI_delay();
	SPI_SDI=1;
	SPI_delay();
	SPI_SCK=1;
	
	Spi_SDI_Read();
  SPI_delay();
	
  data = SPI_Receiver_Dat();
  SPI_delay();
	Spi_SDI_Write();
	
  SPI_delay();	
  SPI_CSX=1;
	
	
  SPI_CSX=0;
  SPI_delay();	
	SPI_SCK=0;
	SPI_delay();
	SPI_SDI=0;
	SPI_delay();
	SPI_SCK=1;
	SPI_Send_Dat(0x46);
  SPI_CSX=1;
	
  return data;
}




unsigned char SPI_ReadX(unsigned char cmd,unsigned int len,unsigned char *Read)
{
	unsigned char data;
	int i;
    SPI_CSX=0;
	SPI_delay();
	SPI_SCK=0;
	SPI_delay();
	SPI_SDI=0;
	SPI_delay();
	SPI_SCK=1;
	SPI_Send_Dat(0xdf);
    SPI_CSX=1;
	
    SPI_CSX=0;
	SPI_delay();
	SPI_SCK=0;
	SPI_delay();
	SPI_SDI=1;
	SPI_delay();
	SPI_SCK=1;
	SPI_Send_Dat(0x5a);
    SPI_CSX=1;
	
    SPI_CSX=0;
	SPI_delay();
	SPI_SCK=0;
	SPI_delay();
	SPI_SDI=1;
	SPI_delay();
	SPI_SCK=1;
	SPI_Send_Dat(0x69);
    SPI_CSX=1;
	
    SPI_CSX=0;
	SPI_delay();
	SPI_SCK=0;
	SPI_delay();
	SPI_SDI=1;
	SPI_delay();
	SPI_SCK=1;
	SPI_Send_Dat(0x02);
    SPI_CSX=1;
	
    SPI_CSX=0;
	SPI_delay();
	SPI_SCK=0;
	SPI_delay();
	SPI_SDI=1;
	SPI_delay();
	SPI_SCK=1;
	SPI_Send_Dat(0x01);
    SPI_CSX=1;


    SPI_CSX=0;
	SPI_delay();
	SPI_SCK=0;
	SPI_delay();
	SPI_SDI=0;
	SPI_delay();
	SPI_SCK=1;
	SPI_Send_Dat(0xe7);
    SPI_CSX=1;
	
    SPI_CSX=0;
	SPI_delay();
	SPI_SCK=0;
	SPI_delay();
	SPI_SDI=1;
	SPI_delay();
	SPI_SCK=1;
	SPI_Send_Dat(0x11);
    SPI_CSX=1;
	
    SPI_CSX=0;
	SPI_delay();
	SPI_SCK=0;
	SPI_delay();
	SPI_SDI=0;
	SPI_delay();
	SPI_SCK=1;
    SPI_Send_Dat(cmd);

	SPI_SCK=0;
	SPI_delay();
	SPI_SDI=1;
	SPI_delay();
	SPI_SCK=1;
	
	Spi_SDI_Read();
    SPI_delay();
	
	for(i=0;i<len;i++)
	{
      *(Read+i)= SPI_Receiver_Dat();
	}
	
    SPI_delay();
	Spi_SDI_Write();
	
    SPI_delay();	
    SPI_CSX=1;
	
	
//    SPI_CSX=0;
//    SPI_delay();	
//	SPI_SCK=0;
//	SPI_delay();
//	SPI_SDI=0;
//	SPI_delay();
//	SPI_SCK=1;
//	SPI_Send_Dat(0x46);
//    SPI_CSX=1;
	
    return data;
	
}


void SPI_Write_4data(unsigned char cmd, unsigned char data1, unsigned char data2, unsigned char data3, unsigned char data4)
{
    SPI_CSX=0;
    
	SPI_SCK=0;
	SPI_delay();
	SPI_SDI=0;
	SPI_delay();
	SPI_SCK=1;
    SPI_delay();
    SPI_Send_Dat(cmd);
    
	SPI_SCK=0;
	SPI_delay();
	SPI_SDI=1;
	SPI_delay();
	SPI_SCK=1;
    SPI_delay();
    SPI_Send_Dat(data1);
    
    SPI_Send_Dat(data2);
    
    SPI_Send_Dat(data3);
    
    SPI_Send_Dat(data4);
    
    SPI_CSX=1;
    SPI_delay();
//    SPI_delay();
    
}

void SPI_Write_cmd(unsigned char cmd)
{
  SPI_CSX=0;
    
  SPI_DCX=0;
	SPI_delay();
	SPI_Send_Dat(cmd);
	
	SPI_CSX=1;
//	SPI_delay(); 
}


/**********************************************
ģʽ��           д����
***********************************************/
#if _CPOL==0&&_CPHA==0          //MODE   0  0   
void SPI_Send_Dat(unsigned char dat)
{
//    unsigned char n;
//	
//    for(n=0;n<8;n++)
//    {
//       SPI_SCK=0; 
//        if(dat&0x80)
//            SPI_SDI=1;
//        else 
//            SPI_SDI=0;
//        SPI_delay();
//        dat<<=1;
//		
//        SPI_SCK=1;
//        SPI_delay();
//    }
	
   unsigned char n;
   
   for(n=0; n<8; n++)   
   {  
   if(dat&0x80) SPI_SDI=1;
       else SPI_SDI=0;
      dat<<= 1;

      SPI_SCK=0;//_nop_(); _nop_();_nop_();_nop_();
      SPI_SCK=1;//_nop_();_nop_();_nop_();_nop_();
   }

		
}

void SPI_Send_Dat2(unsigned char dat1,unsigned char dat2)
{
//    unsigned char n;
//	
//    for(n=0;n<8;n++)
//    {
//       SPI_SCK=0; 
//        if(dat&0x80)
//            SPI_SDI=1;
//        else 
//            SPI_SDI=0;
//        SPI_delay();
//        dat<<=1;
//		
//        SPI_SCK=1;
//        SPI_delay();
//    }
	
   unsigned char n,dat=0x3c;
	SPI_SCK=0;//_nop_(); _nop_();_nop_();_nop_();
	SPI_SDI=1;
//	SPI_DCX=1;
    SPI_SCK=1;//_nop_();_nop_();_nop_();_nop_();
   for(n=0; n<8; n++)   
   {  
   
	   if(dat1&0x80) SPI_SDI=1;
       else SPI_SDI=0;
          dat1<<= 1;
	   if(dat2&0x80) SPI_DCX=1;
       else SPI_DCX=0;
          dat2<<= 1;
	   
      SPI_SCK=0;//_nop_(); _nop_();_nop_();_nop_();
      SPI_SCK=1;//_nop_();_nop_();_nop_();_nop_();
   }

		
}

/*********************************************
ģʽ��         ������
*********************************************/
unsigned char SPI_Receiver_Dat(void)
{
//    unsigned char n ,dat,bit_t;
//    for(n=0;n<8;n++)
//    {
//        SPI_SCK=0;
//        SPI_delay();
//        dat<<=1;
//        if(SPI_RSDI)
//            dat|=0x01;
//        else 
//            dat&=0xfe; 
//        SPI_SCK=1;        
//        SPI_delay();
//    }

//    return dat;
	
	
// unsigned int i=0,dat=0;
// 
// 
// for(i=0;i<8;i++)
// {

//  SPI_SCK=0;
//  Spi_SDI_Read();//  Read_IC_Mode;  
//  SPI_delay();
//  dat=(dat<<1)|SPI_RSDI;
//  Spi_SDI_Write();
//  SPI_delay();
//  SPI_SCK=1;
//  SPI_delay();
// }
// return dat;

    unsigned char n ,dat,bit_t;

	
    SPI_SCK=1;
    SPI_delay();
    for(n=0;n<8;n++)
    {
        SPI_SCK=0;

        SPI_delay();
        SPI_SCK=1;
        dat=(dat<<1)|SPI_RSDI;
//        if(SPI_RSDI)
//            dat|=0x01;
//        else 
//            dat&=0xfe;        
        SPI_delay();
    }

    return dat;

}

unsigned char SPI_Read_BIT(unsigned char cmd)
{
//  unsigned char n ,dat=0,bit_t;
//	
//	
//	SPI_cmd1(cmd);
//	
//	
//    SPI_SCK=1;
//    for(n=0;n<1;n++)
//    {
//        SPI_SCK=0;
//        SPI_delay();
//        dat<<=1;
//        if(SPI_RSDI)
//            dat=1;
//        else 
//            dat=0; 
//        SPI_SCK=1;        
//        SPI_delay();
//    }

//    return dat;

unsigned int Read_ID_1;

  SPI_CSX=0;
    
  SPI_DCX=0;
	SPI_delay();
	SPI_Send_Dat(cmd);
	
	SPI_CSX=1;
  SPI_DCX=1;
	
  SPI_CSX=0;
	Read_ID_1=SPI_Receiver_Dat();
  SPI_CSX=1;
	return Read_ID_1;
}

#endif


/**********************************************
ģʽ��           д����
***********************************************/
#if _CPOL==1&&_CPHA==0           //MODE   1  0
void SPI_Send_Dat(unsigned char dat)
{
 unsigned char n;
 for(n=0;n<8;n++)
 {
  SPI_SCK=1;
  if(dat&0x80)SPI_SDI=1;
  else SPI_SDI=0;
  SPI_delay();
  dat<<=1;
  SPI_SCK=0;
  SPI_delay();
 }
  SPI_SCK=1;
}
/*********************************************
ģʽ��          ������
*********************************************/
//unsigned char SPI_Receiver_Dat(void)
//{
// unsigned char n ,dat,bit_t;
// for(n=0;n<8;n++)
// {
//  SPI_SCK=1;
//  dat<<=1;
//  if(MISO_I())dat|=0x01;
//  else dat&=0xfe;
//  SPI_delay();
//  SPI_SCK=0;
//  SPI_delay();
// }
//  SPI_SCK=1;
//  return dat;
//}

#endif


/*********************************************
ģʽһ        д����
*********************************************/
#if _CPOL==0&&_CPHA==1           //MODE  0  1
void SPI_Send_Dat(unsigned char dat)
{
 unsigned char n;
 SPI_SCK=0;
 for(n=0;n<8;n++)
 {
  SPI_SCK=1;
  if(dat&0x80)SPI_SDI=1;
  else SPI_SDI=0;
  SPI_delay();
  dat<<=1;
  SPI_SCK=0;
  SPI_delay();
 }
}
/*********************************************
ģʽһ       ������
*********************************************/
//unsigned char SPI_Receiver_Dat(void)
//{
// unsigned char n ,dat,bit_t;
// for(n=0;n<8;n++)
// {
//  SPI_SCK=1;
//   dat<<=1;
//  if(MISO_I())dat|=0x01;
//  else dat&=0xfe;
//  SPI_delay();
//  SPI_SCK=0;
//  SPI_delay();
// }
//  SPI_SCK=0;
//  return dat;
//}
#endif


/*********************************************
ģʽ��        д����
*********************************************/
#if _CPOL==1&&_CPHA==1            //MODE  1  1
void SPI_Send_Dat(unsigned char dat)
{
    unsigned char n;

    SPI_SCK=1;
    for(n=0;n<8;n++)
    {
        SPI_SCK=0;
        if(dat&0x80)
            SPI_SDI=1;
        else 
            SPI_SDI=0;
        SPI_delay();
        dat<<=1;
        SPI_SCK=1;
        SPI_delay();
    }
}
/************************************
ģʽ��          ������
************************************/
//unsigned char SPI_Receiver_Dat(void)
//{
// unsigned char n ,dat,bit_t;
// SPI_SCK=0;
// for(n=0;n<8;n++)
// { 
//    SPI_SCK=0;
//    dat<<=1;
//    if(MISO_I())
//        dat|=0x01;
//    else 
//      dat&=0xfe;
//    SPI_delay();
//    SPI_SCK=1;
//    SPI_delay();
// }
//    SPI_SCK=1;
//    return dat;
//}


#endif


//command ģʽ���û��һ����ʾ����
void SPI_DispArea(unsigned int xs, unsigned int ys, 
                  unsigned int xe, unsigned int ye)
{        
    unsigned int size1;
    
//    xs+=0x10;
//    xe+=0x10;
//    
//   SPI_Write_4data(0X2A,xs>>8,xs,xe>>8,xe);
//   SPI_Write_4data(0X2b,ys>>8,ys,ye>>8,ye);
   
	
//    xs+=0x10;
//    xe+=0x10;
    
//    SPI_Write(0X2A,xs>>8,xs,xe>>8,xe);

//    SPI_Write(0X2B,ys>>8,ys,ye>>8,ye);

SPI_cmd1(0x2A);     
SPI_data1(0x00);   
SPI_data1(0x00);   
SPI_data1(0x00);   
SPI_data1(0xEF);   

SPI_cmd1(0x2B);     
SPI_data1(0x00);   
SPI_data1(0x00);   
SPI_data1(0x00);   
SPI_data1(0xEF);  

SPI_cmd1(0X2C);

}


void SPI_RGB(u32 rgb)
{
	
	
	
//    SPI_DCX=1;
    SPI_CSX=0;
	SPI_delay();
    SPI_Send_Dat2(rgb>>8,rgb);
	SPI_CSX=1;
	
	
//    SPI_CSX=0;
//	SPI_delay();
//    SPI_Send_Dat(rgb>>0);
//	SPI_CSX=1;
//	SPI_SCK=0;
//	SPI_delay();
//	SPI_SDI=1;
//	SPI_delay();
//	SPI_SCK=1;
//    SPI_Send_Dat(rgb>>0);
}

unsigned char t=0;
//u8 pix1,pix2;
unsigned char r,g,b;
void SPI_RGB1(u8 rgb)
{
	  	
//	  r=(rgb&0xff0000)>>19;
//	  g=(rgb&0x00ff00)>>10;
//	  b=(rgb&0xff)>>3;
//	
//	  r=r>>3;
//	  g=g>>2;
//	  b=b>>3;	
	
	u16 pix;

	if(t==0)
	{
		t=1;
		r=rgb>>3;	
	}
	else if(t==1)
	{
		t=2;
		g=rgb>>2;	
	}	
	
	else
	{	
		t=0;
		b=rgb>>3;
		pix = (r<<11)|(g<<5)|b;
	    SPI_CSX=0;
		SPI_delay();
		SPI_Send_Dat2(pix>>8,pix);
		SPI_CSX=1;		
	}
	
	
// rgb  rbg grb gbr brg bgr
	
//    SPI_DCX=1;

	
//    SPI_CSX=0;
//	SPI_delay();
//    SPI_Send_Dat(rgb>>0);
//	SPI_CSX=1;
//	SPI_SCK=0;
//	SPI_delay();
//	SPI_SDI=1;
//	SPI_delay();
//	SPI_SCK=1;
//    SPI_Send_Dat(rgb>>0);
}


/********************************* SKYCODE ************************************/
