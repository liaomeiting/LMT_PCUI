/********************************* SKYCODE ************************************
* Copyright (c) 2018, ����˼�����Լ������޹�˾
* All rights reserved.
*
* �ļ���   ��main.c    
* ����     ��S10 
*
* ��    �� ��V2.3.0
* ��    �� ��
* ������� ��2018
* �޸����� ��
*					                          	
******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "sys.h"
#include "S10.h"
#include "Bus.h"
#include "sd_file.h"
#include "ssd2828.h"
#include "in_img.h"
#include "showtext.h"
#include "usart1.h"
#include "bus_rs232_id0.h"
#include "FL.h"
#include "auto_vcom.h"
#include "lwipUser.h"
#include "ff.h"

#include "app_gamma.h"
#include "gammaLinear.h"
#include "gammaRun.h"
/*---------------------------------------------------------------------------*/

extern unsigned int _10ms_ok;  
unsigned int display_on = 0;
unsigned int frame=0;
unsigned int frame_max=0;
unsigned int frame_hold_ms[64];   //���汣��ʱ��
unsigned int frame_hold_cnt;
int auto_switch_mode = 0; //=0 �����л��� =1�Զ��л�

PowerMeasureTypeDef g_power_meas;
WaveMeasureTypeDef g_meter_meas;


/* --------------------------------------------------------------------------*/
void S20_Init(void);
void NVIC_Configuration(void);
void SwitchFrame(unsigned int frame);
void Display_ON(void);
void Display_OFF(void);
void Sleep_In(void);
void Sleep_Out(void);
void MIPI_Init(void);
void LCD_RST_0(void);
void LCD_RST_1(void);
void LCD_BIST_0(void);
void LCD_BIST_1(void);
void SetVCOM(unsigned int vcom);
int GetFlicker(float *flicker);
void AutoOTP(void);
/* --------------------------------------------------------------------------*/

/*�����޸�*/
#define IO_OE_H() GPIO_SetBits(GPIOE, GPIO_Pin_11)
#define IO_OE_L() GPIO_ResetBits(GPIOE, GPIO_Pin_11)

/* --------------------------------------------------------------------------*/

/*ͨ��IO��ʼ��*/
void IO_Configuration(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB|RCC_AHB1Periph_GPIOD|RCC_AHB1Periph_GPIOC|RCC_AHB1Periph_GPIOG, ENABLE); 
    
    //OE �����޸�
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;	
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;   
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; 
    GPIO_Init(GPIOE, &GPIO_InitStructure);	
    IO_OE_L();

    /*------------------------------------------------*/
    /*�û�IO*/
    
    //RST->PB7   
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;	
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;   
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; 
    GPIO_Init(GPIOB, &GPIO_InitStructure);	  
    
    //BIST
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;	
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;   
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; 
    GPIO_Init(GPIOB, &GPIO_InitStructure);	  
    
}

void LCD_RST_0(void)
{
    GPIO_ResetBits(GPIOB, GPIO_Pin_7);
}

void LCD_RST_1(void)
{
    GPIO_SetBits(GPIOB, GPIO_Pin_7);
}

void LCD_BIST_0(void)
{
    GPIO_ResetBits(GPIOB, GPIO_Pin_6);
}

void LCD_BIST_1(void)
{
    GPIO_ResetBits(GPIOB, GPIO_Pin_6);
}

int ssss(void)
{


}
/* --------------------------------------------------------------------------*/

///////////////////////////////////////////////////////////////////////////////
char bb[16];
void UDPTTest(void)
{
	int i = 0;
	
	i = UDPRecive(bb,16);
	if (i > 0)
	{
		UDPSend(bb,i);
		UDPSend("rec",3);
	}
}

int main(void)
{    
    u8 key;
    float flk;
    char str[8];
    int udp_state;
    u8 remoteIP[4] = {192,168,1,23};
	u8 ip[4]      = {192,168,1,123};
	u8 netmask[4] = {255,255,255,0};
	u8 gateway[4] = {192,168,1,1};
    PowerAlarmTypeDef Alarm;
    int expwm=0;
    unsigned int dd[3];
    int res;
    
    /*S10���Ӳ����ʼ��*/
    S10_Init();
        
    /*ͨ��IO��ʼ��*/
    IO_Configuration();
    IOVOL_Set(1.8);  //IO�����ѹ�趨 =ģ��IOVCC
    
    KEY_SetLED(KEY_ONOFF, KEYLED_OFF);
    KEY_SetLED(KEY_DOWN, KEYLED_ON);
    KEY_SetLED(KEY_UP, KEYLED_OFF);
    KEY_SetLED(KEY_ENTER, KEYLED_ON);
    
    Delay_ms(500);
    KEY_SetLED(KEY_ONOFF, KEYLED_ON);
    KEY_SetLED(KEY_DOWN, KEYLED_OFF);
    KEY_SetLED(KEY_UP, KEYLED_ON);
    KEY_SetLED(KEY_ENTER, KEYLED_OFF);
    
    Delay_ms(500);
    KEY_SetLED(KEY_ONOFF, KEYLED_ON);
    KEY_SetLED(KEY_DOWN, KEYLED_ON);
    KEY_SetLED(KEY_UP, KEYLED_ON);
    KEY_SetLED(KEY_ENTER, KEYLED_ON);
    
    
    /*������ʼ��*/  
//    FL_Init(0);
        GAMMA_Inint();
        CA310_StepGetdB();
        
//    MONITOR_Printf("Init LWIP ...\r\n");
//	udp_state=LwipInit(ip,netmask,gateway);  //-1�ڴ�������� -2Ӳ������  -3û������
//    if(udp_state < 0)
//    {
//        MONITOR_Printf("  %d NG\r\n",udp_state);
//    }
//    
//    if(udp_state>=0){UDPInit(remoteIP,6000,6000);}
    
    AutoVcomInit(SetVCOM, GetFlicker);
    
    
    res=SDCard_getSave("xx3.bin",dd,sizeof(dd));
    if(res>=0)
    {
        MONITOR_Printf("rdsdcard res=%d; %d,%d,%d\r\n",res,dd[0],dd[1],dd[2]);
    }
    else
    {
        MONITOR_Printf("rdsdcard ng\r\n");
        dd[0]=0;dd[1]=0;dd[2]=0;
    }
    
    dd[0] = dd[0]+1;
    dd[1] = dd[0]+1;
    dd[2] = dd[0]+2;
    SDCard_Save("xx3.bin",dd,sizeof(dd));
    
    
    /**/
    MONITOR_SetName(WAVE1_NAME,"PWM");
    MONITOR_SetName(WAVE2_NAME,"TE");
    MONITOR_SetName(VDD1_NAME,"IOVCC");
    MONITOR_SetName(VDD2_NAME," ");
    MONITOR_SetName(VDD3_NAME," ");
    MONITOR_SetName(VDD4_NAME,"VSP");
    MONITOR_SetName(VDD5_NAME,"VSN");

    /*��ʾ��Ŀ����*/
    MONITOR_SetProjectName("VIDEO 1080x2340");
    
    /*-----LCD �����趨---*/        
    /*LCD �ӿ�ģʽ*/
    gLCD_IFMODE = MIPI_VIDEO_8LANE;   

    /*�ֱ�������*/ 
    gLCD_XSIZE = 1600;
    gLCD_YSIZE = 2560;
        
    /*VIDEOģʽ RGBʱ�����ã�ֻVIDEOģʽ��Ч*/
    gLCD_PCLK = 150;  //��λMHz ����0.1MHz
    
    gLCD_HBPD = 45;
    gLCD_HFPD = 112;
    gLCD_HSPW = 12;
        
    gLCD_VBPD = 8;
    gLCD_VFPD = 12;
    gLCD_VSPW = 4;

    gLCD_PCLK_EDGE = RISING_EDGE;    //lcd��������ʱ��PCLK����
    gLCD_HS_POLARITY = ACTIVE_LOW;   //HSYNC���弫��			  
    gLCD_VS_POLARITY = ACTIVE_LOW;   //VSYNC���弫��			  
    gLCD_DE_POLARITY = ACTIVE_HIGH;  //DE�ź���Ч��ƽ	

    /*COMMAND ģʽÿlane���������ã�ֻCOMMANDģʽ��Ч*/
    gHS_Mbps = 800;
    
    GPU_Config();
    
    /*�л�����ķ�ʽ*/
    auto_switch_mode = 0; //=0 �����л��� =1�Զ��л�
    
    /*���ػ���, �����û���ͣ��ʱ��*/
    _DEBUG("Load image..\n\r");
        
    GPU_LoadFrame(frame_max);         //���ص�0����
    SDCard_BMP("1600x2560_01.bmp");   //����ͼ��
    frame_hold_ms[frame_max++] = 0;   //���汣��ʱ��

    GPU_LoadFrame(frame_max);         //���ص�2����
    SDCard_BMP("1600x2560_02.bmp");
    frame_hold_ms[frame_max++] = 0;   //���汣��ʱ��
        
    GPU_LoadFrame(frame_max);
    Img_Full(0,255,0);
    frame_hold_ms[frame_max++] = 0;
    
     GPU_LoadFrame(frame_max);
    Img_Chcker58();
    frame_hold_ms[frame_max++] = 0;
    
    GPU_LoadFrame(frame_max);
    Img_Box();
    frame_hold_ms[frame_max++] = 0;
    
    GPU_LoadFrame(frame_max);
    Img_Gray256_H();
    frame_hold_ms[frame_max++] = 0;
    
    GPU_LoadFrame(frame_max);
    Img_Gray256_V();;
    frame_hold_ms[frame_max++] = 0;
    
    GPU_LoadFrame(frame_max);
    Img_ColorBar();
    frame_hold_ms[frame_max++] = 0;
    
    _DEBUG("Load image OK\n\r");
    
    KEY_SetLED(KEY_ONOFF, KEYLED_OFF);
    KEY_SetLED(KEY_DOWN, KEYLED_OFF);
    KEY_SetLED(KEY_UP, KEYLED_OFF);
    KEY_SetLED(KEY_ENTER, KEYLED_OFF);
    
    /*������*/
    Display_ON();
    SwitchFrame(0);
        
    while (1)
    {
        key=KEY_Read();                    
        switch(key)
        { 
            case KEY_ONOFF:
                if(display_on == 0)
                {
                    Display_ON();
                    SwitchFrame(0);
                }
                else
                {
                    Display_OFF();
                    display_on = 0;
                }
                break;
            
            case KEY_DOWN: //�·�
                if((auto_switch_mode==1) || (display_on==0)){break;}//���Զ��л����� �� DisplayOFF�˰�����
                
                if(frame_hold_cnt < frame_hold_ms[frame]) break;
                frame_hold_cnt = 0;
                
                if(++frame >= frame_max){frame = 0;} 
                
                SwitchFrame(frame);
                
                break;
                
            case KEY_UP: //�Ϸ�
                if((auto_switch_mode==1) || (display_on==0)){break;}//���Զ��л����� �� DisplayOFF�˰�����
                
                if(frame_hold_cnt < frame_hold_ms[frame]) break; //��������ʱ��
                frame_hold_cnt = 0;
                
                if(frame == 0){frame = frame_max-1;} 
                else {frame--;}
                
                SwitchFrame(frame);
                            
                break;   
                
                
            case KEY_OTP:
//                if((auto_switch_mode==1) || (display_on==0)){break;}//���Զ��л����� �� DisplayOFF�˰�����
//                KEY_SetLED(KEY_OTP, KEYLED_ON);
//                
//                SwitchFrame(0);
//                if(GetFlicker(&flk)<0)
//                {
//                    ShowString(0,1000,FONT4080,0xFF0000,0X000000,"xxxxxx    ");
//                    Delay_ms(100);
//                    ShowString(0,1000,FONT4080,0xFF0000,0X000000,"FL1 NG    ");
//                }
//                else
//                {
//                    sprintf(str,"%3.1f%%  ",flk);
//                    ShowString(0,1000,FONT4080,0x00FF00,0X000000,str);
//                }

//                KEY_SetLED(KEY_OTP, KEYLED_OFF);
                POWER_GetAlarmFlag(&Alarm);
                
                _DEBUG("I1:0x%02x, I2:0x%02x, I3:0x%02x, I4:0x%02x, I5:0x%02x; T=%d\r\n",Alarm.VDD_I_Alarm[0],Alarm.VDD_I_Alarm[1],Alarm.VDD_I_Alarm[2],Alarm.VDD_I_Alarm[3],Alarm.VDD_I_Alarm[4],
                 Alarm.VDD_Alarm_Time[2]);
                 
                 if(expwm==0){LED_ExPWMOn();expwm=1;}
                 else{LED_ExPWMOff();expwm=0;}
                break;
        }
        
        /*�Զ��л�����ͻ��汣��*/
        if((auto_switch_mode == 1) && (_1ms_ok == 1) && (display_on == 1)) 
        {
            _1ms_ok = 0;
            if(++frame_hold_cnt >= frame_hold_ms[frame])  
            {
                frame_hold_cnt = 0;
                if(frame<(frame_max-1)){frame++;}
                else {frame = 0;}
                SwitchFrame(frame);	
            }
        }
        else if((auto_switch_mode == 0) && (_1ms_ok == 1) && (display_on == 1))
        {
            _1ms_ok = 0;
            if(frame_hold_cnt < frame_hold_ms[frame])  
            {
                ++frame_hold_cnt;
            }
        }
        
        UDPTTest();
    }
}

/*�л�������ƣ�������� �������õ�*/
void SwitchFrame(unsigned int frame)
{   
    char str[16];
    switch(frame)
    {
        case 0:  //��0�����������
//            POWER_SetIxAlarmValueMA(1, 62, 18);
//            POWER_SetIxAlarmValueMA(2, 1.5, 0.8);
//            POWER_SetIxAlarmValueMA(3, 1.6, 1.2);
//            POWER_SetIxAlarmValueMA(4, 18, 5);
//            POWER_SetIxAlarmValueMA(5, 18, 6);
//        
//            POWER_SetVxAlarmValue(1, 1.9, 1.7);
//            POWER_SetVxAlarmValue(2, 3.4, 3.2);
//            POWER_SetVxAlarmValue(3, 3.4, 3.2);
//            POWER_SetVxAlarmValue(4, 5.6, 5.4);
//            POWER_SetVxAlarmValue(5, -5.4, -5.6);
//        
//            
//        
////            LED_SetVxAlarmValue(26,22);
////            LED_SetIxAlarmValue(61, 59);
//        
//            WAVE_SetFreqxAlarmValue(1, 29000, 25500);
//            WAVE_SetFreqxAlarmValue(2, 72, 70);
//        
//            WAVE_SetDutyxAlarmValue(1,55,46);
//            WAVE_SetDutyxAlarmValue(2,8,5);
//        
//            WAVE_SetIDRAlarmValue(110.0F, 90.0F);
//           // WAVE_SetIDVAlarmValue(1.9, 1.7);
//        
//            S10_StartAlarm();
            ShowString(0,50,FONT4080,RED,WHITE,"SkyCode+-*/1234567890ABCDEFG");
            ShowString(200,150,FONT4080,BLUE,WHITE,"SkyCode+-*/1234567890ABCDEFG");
            ShowString(1777,300,FONT4080,GREEN,WHITE,"SkyCode+-");
            break;
        
        case 1:
            
            break;
        
        case 3: //����
//            S10_StopAlarm();    //ֹͣ��������
//            Sleep_In();         //ģ���������
//        
//            /*VDD���������л��� uA ��*/
//            POWER_SetIxMeaRange(1, RANGE_UA);   
//            POWER_SetIxMeaRange(4, RANGE_UA);   
//            POWER_SetIxMeaRange(5, RANGE_UA);
//        
//            Delay_ms(500);  //��ģ���ȶ� �� ������������ȶ�
//        
//            /*�������� VDD �������� ����*/
//            POWER_SetIxAlarmValueUA(1, 500, 200);  //VDD1 ��������500uA ����200uA
//            POWER_SetIxAlarmValueUA(4, 200, 0);    //VDD4 ��������200uA ����0uA
//            POWER_SetIxAlarmValueUA(5, 50, 0);     //VDD5 ��������50uA ����0uA
//        
//            /*�������� PWM TE���������޶�ֵ����*/
//            WAVE_SetFreqxAlarmValue(1, LIMITNULL, LIMITNULL); //WAVE1(PWM) Ƶ�� ������
//            WAVE_SetDutyxAlarmValue(1, LIMITNULL, LIMITNULL); //WAVE1(PWM) ռ�ձ� ������
//            WAVE_SetFreqxAlarmValue(2, LIMITNULL, LIMITNULL); //WAVE2(TE) Ƶ�� ������
//                                                      
//            S10_StartAlarm();   //������������

            break;
        
        case 4: //�˳�����
//            S10_StopAlarm();    //ֹͣ��������
//        
//            /*VDD���������л��� mA ��*/
//            POWER_SetIxMeaRange(1, RANGE_MA);   
//            POWER_SetIxMeaRange(4, RANGE_MA);   
//            POWER_SetIxMeaRange(5, RANGE_MA);
//        
//            POWER_SetIxAlarmValueMA(1, 62, 18);
//            POWER_SetIxAlarmValueMA(2, 1.5, 0.8);
//            POWER_SetIxAlarmValueMA(3, 1.6, 1.2);
//            POWER_SetIxAlarmValueMA(4, 18, 5);
//            POWER_SetIxAlarmValueMA(5, 18, 6);
//        
//            POWER_SetVxAlarmValue(1, 1.9, 1.7);
//            POWER_SetVxAlarmValue(2, 3.4, 3.2);
//            POWER_SetVxAlarmValue(3, 3.4, 3.2);
//            POWER_SetVxAlarmValue(4, 5.6, 5.4);
//            POWER_SetVxAlarmValue(5, -5.4, -5.6);
//        
//            
//        
////            LED_SetVxAlarmValue(26,22);
////            LED_SetIxAlarmValue(61, 59);
//        
//            WAVE_SetFreqxAlarmValue(1, 29000, 25500);
//            WAVE_SetFreqxAlarmValue(2, 72, 70);
//        
//            WAVE_SetDutyxAlarmValue(1,55,46);
//            WAVE_SetDutyxAlarmValue(2,8,5);
//        
//            WAVE_SetIDRAlarmValue(110.0F, 90.0F);
//        
//            Sleep_Out();  //�˳�����
//            Delay_ms(500);
//            S10_StartAlarm();   //������������
            break;
    }
    
    GPU_DisplayFrame(frame);
    
    if(frame==0)
    {
        POWER_GetMeasure(&g_power_meas);
        sprintf(str, "V6=%.1fV",g_power_meas.VDD_V[5]);
        if((g_power_meas.VDD_V[5]>=5.9F) && (g_power_meas.VDD_V[5]<=6.1F))
        {
            ShowString(0,50,FONT4080,0xff00,0x000000,str);
        }
        else
        {
            ShowString(0,50,FONT4080,0xff0000,0x000000,str);
        }
        
        sprintf(str, "V7=%.1fV",g_power_meas.VDD_V[6]);
        if((g_power_meas.VDD_V[6]>=6.9F) && (g_power_meas.VDD_V[6]<=7.1F))
        {
            ShowString(0,50+80,FONT4080,0xff00,0x000000,str);
        }
        else
        {
            ShowString(0,50+80,FONT4080,0xff0000,0x000000,str);
        }
        
        sprintf(str, "V8=%.1fV",g_power_meas.VDD_V[7]);
        if((g_power_meas.VDD_V[7]>=7.9F) && (g_power_meas.VDD_V[7]<=8.1F))
        {
            ShowString(0,50+80+80,FONT4080,0xff00,0x000000,str);
        }
        else
        {
            ShowString(0,50+80+80,FONT4080,0xff0000,0x000000,str);
        }
//        sprintf(str, "V6=%.1f, V7=%.1f, V8=%.1f%",g_power_meas.VDD_V[5],g_power_meas.VDD_V[6],g_power_meas.VDD_V[7]);
//        ShowString(0,50,FONT4080,0xff0000,0x000000,str);
    }
        
}


/*�ϵ�˳��*/
void Display_ON(void)
{
    int res;
    IOVOL_Set(1.8);
    IO_OE_H();  
    SSD2828_POWER_ON();
    KEY_SetLED(KEY_ONOFF, KEYLED_ON);
    
//    POWER_SetVDD(2, 3.3);
//    POWER_SetVDD(3, 3.3);
            
    /*LCM �ϵ�˳��*/
    LCD_BIST_0();
    POWER_SetVDD(1, 1.8);
    Delay_ms(50);
    POWER_SetVDD(4, 5.5);
    Delay_ms(10);
    POWER_SetVDD(5, -5.5);
    Delay_ms(100);
    
    SSD2828_Config();  //����SS2828
    
    LCD_RST_0();
    Delay_ms(50);
    LCD_RST_1();
    Delay_ms(100);
    
    if(PD_VideoMode())
    {
        GPU_RGB_ON();
    }
    
    MIPI_Init();
    
    GPU_DisplayFrame(frame=0);
    
//    POWER_SetVDD(6,6);
//    POWER_SetVDD(7,7);
//    POWER_SetVDD(8,8);
        
    /**/
    LED_SetI(1,20);
    LED_SetI(2,20);
    LED_SetI(3,10);
    LED_SetI(4,10);
//    
    display_on = 1;
//    LED_SetVoltage(0); //LED(��GND)��ѹ����Ϊ26V
    res = LED_ON();
    if(res == 0)
    {                  //������������
        _DEBUG("LED ON OK\r\n");
        _DEBUG("Display ON\n\r");
        MONITOR_ShowPage(0);
    }
    else
    {                  //��������ʧ�� �ж�·��ͨѶʧ��
        _DEBUG("LED ON NG res=%d\r\n",res);
//        Display_OFF();
        MONITOR_ShowPage(10);
    }
}

/*����˳��*/
void Display_OFF(void)
{        
    S10_StopAlarm(); 
    
//    POWER_SetIxMeaRange(1, RANGE_MA);   
//    POWER_SetIxMeaRange(4, RANGE_MA);   
//    POWER_SetIxMeaRange(5, RANGE_MA);

    LED_OFF();
    
    SSD2828_DcsShortWrite(1); 
    SSD2828_WriteData(0x28);
    Delay_ms(20);
    
    SSD2828_DcsShortWrite(1);
    SSD2828_WriteData(0x10);
    Delay_ms(120);
    
    LCD_RST_0();
    Delay_ms(5); 
    POWER_SetVDD(5, 0);
    Delay_ms(5);
    POWER_SetVDD(4, 0);
    Delay_ms(5);  
    Delay_ms(5);    
    POWER_SetVDD(1, 0);
    Delay_ms(10);    
    
    POWER_SetVDD(2, 0);
    POWER_SetVDD(3, 0);

    SSD2828_WriteReg(0xb7,0x03,0x00);  //SSD2828  VIDEO MODE OFF
	SSD2828_WriteReg(0xb7,0x03,0x04);  //SSD2828 ENTERS ULP MODE
	SSD2828_WriteReg(0xb9,0x00,0x00);  //SSD2828 PLL OFF

//    SSD2828_POWER_OFF();
//    SSD2828_RST_L();
    
    POWER_SetVDD(6,0);
    POWER_SetVDD(7,0);
    POWER_SetVDD(8,0);
    
    KEY_SetLED(KEY_ONOFF, KEYLED_OFF);
    display_on = 0;
    
//    IOVOL_Set(0);
    IO_OE_L();
}

/*����*/
void Sleep_In(void)
{
//    SSD2828_Init();

    SSD2828_A_CS_0();
    SSD2828_B_CS_0();

    SSD2828_LP();
    
    MIPI_WR(0x05,0x28);
    Delay_ms(20);
    
    MIPI_WR(0x05,0x10);
    Delay_ms(120);
    
    SSD2828_WriteReg(0xb7,0x03,0x00);  //SSD2828  VIDEO MODE OFF
	SSD2828_WriteReg(0xb7,0x03,0x04);  //SSD2828 ENTERS ULP MODE
	SSD2828_WriteReg(0xb9,0x00,0x00);  //SSD2828 PLL OFF
	
//     LCD_RST_0();
    
	Delay_ms(20);
//    SSD2828_Video();
}

void Sleep_Out(void)
{
  	//---tft init------------
    
//	Delay_ms(20);
//	SSD2828_WriteReg(0xb9,0x00,0x01);  //SSD2828 PLL ON 
//	SSD2828_WriteReg(0xb7,0x03,0x00);  //SSD2828 LEAVES ULP MODE

    SSD2828_Config();
    
	SSD2828_LP();  
	
    MIPI_WR(0x05,0x11); // Sleep-Out
    Delay_ms(120);
    
    MIPI_WR(0x05,0x29); // Display On
    Delay_ms(20);
    
	if(PD_CommandMode())
    {
        SSD2828_HS();
    }
    else
    {
        SSD2828_Video();
    }
}

/*д��ʼ������*/
void MIPI_Init(void)
{
    u8 read_data[4];
    
    /*2828����LP ģʽ*/
    SSD2828_A_CS_0();
    SSD2828_B_CS_0();
    SSD2828_LP();
 
    MIPI_WR(0x05,0x01);
    Delay_ms(15);
    MIPI_WR(0x39,0x36,0x00);
    MIPI_WR(0x39,0x3A,0x70);
    MIPI_WR(0x39,0x35,0x00);
    MIPI_WR(0x39,0x51,127);
    MIPI_WR(0x39,0x53,0x24);
	Delay_ms(15);
	SSD2828_A_CS_0();
	SSD2828_B_CS_1();
    if(SSD2828_DcsReadDT06(0x54, 1, read_data) == MIPI_READ_SUCCEED)
    {
        _DEBUG("2828A REG53 =0x%x\r\n", read_data[0]);
    }
    else
    {
        _DEBUG("2828A rd reg53 NG \r\n");
    }
	SSD2828_A_CS_1();
	SSD2828_B_CS_0();
    if(SSD2828_DcsReadDT06(0x54, 1, read_data) == MIPI_READ_SUCCEED)
    {
        _DEBUG("2828B REG53 =0x%x\r\n", read_data[0]);
    }
    else
    {
        _DEBUG("2828B rd reg53 NG \r\n");
    }

	SSD2828_A_CS_0();
	SSD2828_B_CS_0();    
   
    MIPI_WR(0x05,0x29);
    Delay_ms(20);
    
    MIPI_WR(0x05,0x11);
    Delay_ms(140);
    
    MIPI_WR(0x05,0x11);
    Delay_ms(140);
    MIPI_WR(0x05,0x29);
    Delay_ms(20);
    
    /*--2828����HS or videoģʽ--*/
    if(PD_CommandMode())
    {
        SSD2828_HS();
    }
    else
    {
        SSD2828_Video();
    }
}


//��ģ�M�ļĴ�����VCOMֵ
void SetVCOM(unsigned int vcom)
{

    MIPI_WR(0X39,0X00,0X01);                                                                                                
    MIPI_WR(0X39,0XD9,vcom); //VCOM

    MIPI_WR(0X39,0X00,0X02);                                                                                                
    MIPI_WR(0X39,0XD9,vcom); //VCOM
    
        		
    /*--2828����HS or videoģʽ--*/
    if(PD_CommandMode())
    {
        SSD2828_HS();
    }
    else
    {
        SSD2828_Video();
    }
	
}

int GetFlicker(float *flicker)
{
    float flick;
    int res=1;
    unsigned int cnt=0;
    
    while(FV_NEW!=FL_RdFlicCont(0,&flick))
    {
        if(++cnt > 20) {res=-1; break;}
    }
    
    *flicker = flick;
    return res;
}


void AutoOTP(void)
{
    int res;
    unsigned int vcom=0;
    static unsigned int s_vcom;
    static int first = 0;
    float flk;
    
    MONITOR_Printf("AUTO OPT\r\n");
    
    if(FL_RdFlicCont(0,&flk)==FV_ERROR)  //�ж�����̽ͷ
    {
        MONITOR_Printf("ON FL1 exit\r\n");
        return;
    }
    
    /*Ѱ�����VCOM*/
    MONITOR_Printf("scan vcom\r\n");

    /*�� 1 ����OTP ��Χɨ��VCOM*/
    if(first==0) 
    {   
        MONITOR_Printf("1 scan vcom ..\r\n");
        res = AutoVcom_ScanRange(50,200,5,500,&vcom);

        if(res == AUTOVCOM_EXIT){MONITOR_Printf("key exit\r\n");return;}; //�����˳�
        if(res==AUTOVCOM_ERROR){MONITOR_Printf("scan eorr\r\n"); return;} 
    
        MONITOR_Printf("1 scan vcom ok\r\n");
        MONITOR_Printf("1 good vcom =%d \r\n", vcom);
        
        s_vcom = vcom;
        first = 1;//�´β���
    }
    
    /*��2��ɨ��VCOM��������ֵ��ʼ*/
    MONITOR_Printf("2 scan vcom...\r\n");
    res = AutoVcom_ScanDef(s_vcom, 2, 500, &vcom); //����2
    if(res == AUTOVCOM_EXIT){MONITOR_Printf("key exit\r\n");return;}; //�����˳�
    if(res == AUTOVCOM_ERROR){MONITOR_Printf("scan eorr\r\n"); return;} 
    
    MONITOR_Printf("2 scan vcom ok\r\n");
    MONITOR_Printf("2 good vcom =%d \r\n", vcom);
    
    /*��3�� С��Χ*/
    MONITOR_Printf("3 scan vcom ..\r\n");
    res = AutoVcom_ScanRange(vcom-3,vcom+3,1,500,&vcom);

    if(res == AUTOVCOM_EXIT){MONITOR_Printf("key exit\r\n");return;}; //�����˳�
    if(res==AUTOVCOM_ERROR){MONITOR_Printf("scan eorr\r\n"); return;} 

    MONITOR_Printf("3 scan vcom ok\r\n");
    MONITOR_Printf("3 vcom =%d \r\n", vcom);
    
}


//int fputc(int ch, FILE *f)
//{

////    /*printfӳ�䵽UART1*/
////    USART_SendData(USART1, (unsigned char) ch);
////    while (!(USART1->SR & USART_FLAG_TXE));

////    /*printfӳ�䵽BUSRS232 ID0*/
////    u8 a;
////    a=ch;
////    BusRS232_ID0_SendData(1, &a);
//    
//    return ch;
//}



/********************************* SKYCODE ***********************************/
