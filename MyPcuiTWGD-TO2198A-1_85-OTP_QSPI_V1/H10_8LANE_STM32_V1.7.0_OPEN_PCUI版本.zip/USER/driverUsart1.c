#include "driverUsart1.h"

static sky_comDriver Usart1_Driver;

static int usart1_write(struct _Tsky_comDriver *self, uint8_t *data, int len);//����1д����

/*******************************************************************************
 * ������ : driverUSART1_Init
 * ��  �� : ����1������ʼ��
 * ��  �� : ��
 * ��  �� : sky_comDriver�ṹ��ָ����
*******************************************************************************/
sky_comDriver *driverUSART1_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	memset(&Usart1_Driver, 0, sizeof(sky_comDriver));
	
	Usart1_Driver.write = usart1_write;//ע��д����
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_USART1);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_USART1);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No ;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART1, &USART_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 5;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
	
	USART_Cmd(USART1, ENABLE);
	
	return &Usart1_Driver;
}

/*******************************************************************************
 * ������ : usart1_write
 * ��  �� : ����1д����
 * ��  �� : *self:_Tsky_comDriver�ṹ��ָ��
 * ��  �� : *data:Ҫд������
 * ��  �� : len:���ݳ���
 * ��  �� : 0
*******************************************************************************/
static int usart1_write(struct _Tsky_comDriver *self, uint8_t *data, int len)
{
	while(len > 0)
	{
		while((USART1->SR & 0x40) == 0); 
		USART1->DR = (uint8_t)*data;      
		len--;
		data++;
	}
	
	return 0;
}

/*******************************************************************************
 * ������ : USART1_IRQHandler
 * ��  �� : ����1�ж�����
 * ��  �� : ��
 * ��  �� : 0
*******************************************************************************/
void USART1_IRQHandler(void)
{
	uint8_t Res = 0;
	sky_comDriver *s = &Usart1_Driver;
    
	if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
	{
		Res = USART_ReceiveData(USART1);
		
        Write2dev(s, &Res, 1);
	}
}
