/******************************* ����������� *********************************
 * �ļ���   ��in_img.c        
 * ����     ���������
 * �汾     ��
 * ������� ��2014 
 * ����     ������ͼ��
 * �޸ļ�¼ ��|    ����    |   ����    |    �汾    |    ����    |				
*******************************************************************************/
#include "in_img.h"
#include "gpu.h"

//����
static void DrawLine(u16 x1, u16 y1, u16 x2, u16 y2, u32 color)
{
	u16 t; 
	int xerr=0,yerr=0,delta_x,delta_y,distance; 
	int incx,incy,uRow,uCol; 
	delta_x=x2-x1; //������������ 
	delta_y=y2-y1; 
	uRow=x1; 
	uCol=y1; 
	if(delta_x>0)incx=1; //���õ������� 
	else if(delta_x==0)incx=0;//��ֱ�� 
	else {incx=-1;delta_x=-delta_x;} 
	if(delta_y>0)incy=1; 
	else if(delta_y==0)incy=0;//ˮƽ�� 
	else{incy=-1;delta_y=-delta_y;} 
	if( delta_x>delta_y)distance=delta_x; //ѡȡ�������������� 
	else distance=delta_y; 
	for(t=0;t<=distance+1;t++ )//������� 
	{  
        GPU_GotoLoadFrameXy(uRow,uCol);
        GPU_WrRGB(color); 
        
		xerr+=delta_x ; 
		yerr+=delta_y ; 
		if(xerr>distance) 
		{ 
			xerr-=distance; 
			uRow+=incx; 
		} 
		if(yerr>distance) 
		{ 
			yerr-=distance; 
			uCol+=incy; 
		} 
	}  
}  

void Img_CT(void)
{
    unsigned int y,x;

	for(y=0;y<gLCD_YSIZE/4;y++)
	{
		for(x=0;x<gLCD_XSIZE;x++)
		{ 
			GPU_WrRGB(0x7F7F7F);
		}
	}

	for( ;y<gLCD_YSIZE*3/4;y++)
	{
		for(x=0;x<gLCD_XSIZE/4;x++)
		{
			GPU_WrRGB(0x7F7F7F); 
		} 

	    for(;x<gLCD_XSIZE*3/4;x++)
		{   
			GPU_WrRGB(0x000000); 
		} 
	    for(;x<gLCD_XSIZE;x++)
		{   
			GPU_WrRGB(0x7F7F7F);
		} 
	}

	for(;y<gLCD_YSIZE;y++)
	{
		for(x=0;x<gLCD_XSIZE;x++)
		{ 
			GPU_WrRGB(0x7F7F7F);
		}			
	}

}

void Img_Flicker(void)
{
    unsigned int i, j;

/*	for(j=0;j<gLCD_YSIZE/2;j++)
	{	
		for(i=0;i<gLCD_XSIZE/2;i++)
		{
			GPU_WrRGB(0x7f007f);
            GPU_WrRGB(0x007f00);
		}
        for(i=0;i<gLCD_XSIZE/2;i++)
		{
            GPU_WrRGB(0x007f00);
            GPU_WrRGB(0x7f007f);
		}

	}*/
    
    for(j=0;j<gLCD_YSIZE/2;j++)
	{	
		for(i=0;i<gLCD_XSIZE;i++)
		{
			GPU_WrRGB(0x7F007F);
            GPU_WrRGB(0x007F00);
		}

	}
}


void Img_Full(unsigned char r, unsigned char g, unsigned char b)
{
    unsigned int i, j;
    unsigned int pix;

    pix = (r<<16)|(g<<8)|b;
    
	for(j=0;j<gLCD_YSIZE;j++)
	{	
		for(i=0;i<gLCD_XSIZE;i++)
		{
			GPU_WrRGB(pix);
        }
	}
}


void Img_Chcker58(void)
{
	unsigned int i;
	unsigned int y;

//	for(j=0;j<4;j++)
	{
		for(y=0;y<gLCD_YSIZE*1/8;y++)
		{
			for(i=0	;i<gLCD_XSIZE/5;	i++){GPU_WrRGB(0x000000);}
			for(	;i<gLCD_XSIZE*2/5;i++){GPU_WrRGB(0xFFFFFF);}
			for(	;i<gLCD_XSIZE*3/5;i++){GPU_WrRGB(0x000000);}
			for(	;i<gLCD_XSIZE*4/5;i++){GPU_WrRGB(0xFFFFFF);}
			for(	;i<gLCD_XSIZE;	i++){GPU_WrRGB(0x000000);}
		}

		for(   ;y<gLCD_YSIZE*2/8;y++)
		{
			for(i=0	;i<gLCD_XSIZE/5;	i++){GPU_WrRGB(0xFFFFFF);}
			for(	;i<gLCD_XSIZE*2/5;i++){GPU_WrRGB(0x000000);}
			for(	;i<gLCD_XSIZE*3/5;i++){GPU_WrRGB(0xFFFFFF);}
			for(	;i<gLCD_XSIZE*4/5;i++){GPU_WrRGB(0x000000);}
			for(	;i<gLCD_XSIZE;	i++){GPU_WrRGB(0xFFFFFF);}
		}

		for( ;y<gLCD_YSIZE*3/8;y++)
		{
			for(i=0	;i<gLCD_XSIZE/5;	i++){GPU_WrRGB(0x000000);}
			for(	;i<gLCD_XSIZE*2/5;i++){GPU_WrRGB(0xFFFFFF);}
			for(	;i<gLCD_XSIZE*3/5;i++){GPU_WrRGB(0x000000);}
			for(	;i<gLCD_XSIZE*4/5;i++){GPU_WrRGB(0xFFFFFF);}
			for(	;i<gLCD_XSIZE;	i++){GPU_WrRGB(0x000000);}
		}

		for(   ;y<gLCD_YSIZE*4/8;y++)
		{
			for(i=0	;i<gLCD_XSIZE/5;	i++){GPU_WrRGB(0xFFFFFF);}
			for(	;i<gLCD_XSIZE*2/5;i++){GPU_WrRGB(0x000000);}
			for(	;i<gLCD_XSIZE*3/5;i++){GPU_WrRGB(0xFFFFFF);}
			for(	;i<gLCD_XSIZE*4/5;i++){GPU_WrRGB(0x000000);}
			for(	;i<gLCD_XSIZE;	i++){GPU_WrRGB(0xFFFFFF);}
		}

		for( ;y<gLCD_YSIZE*5/8;y++)
		{
			for(i=0	;i<gLCD_XSIZE/5;	i++){GPU_WrRGB(0x000000);}
			for(	;i<gLCD_XSIZE*2/5;i++){GPU_WrRGB(0xFFFFFF);}
			for(	;i<gLCD_XSIZE*3/5;i++){GPU_WrRGB(0x000000);}
			for(	;i<gLCD_XSIZE*4/5;i++){GPU_WrRGB(0xFFFFFF);}
			for(	;i<gLCD_XSIZE;	i++){GPU_WrRGB(0x000000);}
		}

		for(   ;y<gLCD_YSIZE*6/8;y++)
		{
			for(i=0	;i<gLCD_XSIZE/5;	i++){GPU_WrRGB(0xFFFFFF);}
			for(	;i<gLCD_XSIZE*2/5;i++){GPU_WrRGB(0x000000);}
			for(	;i<gLCD_XSIZE*3/5;i++){GPU_WrRGB(0xFFFFFF);}
			for(	;i<gLCD_XSIZE*4/5;i++){GPU_WrRGB(0x000000);}
			for(	;i<gLCD_XSIZE;	i++){GPU_WrRGB(0xFFFFFF);}
		}

		for(   ;y<gLCD_YSIZE*7/8;y++)
		{
			for(i=0	;i<gLCD_XSIZE/5;	i++){GPU_WrRGB(0x000000);}
			for(	;i<gLCD_XSIZE*2/5;i++){GPU_WrRGB(0xFFFFFF);}
			for(	;i<gLCD_XSIZE*3/5;i++){GPU_WrRGB(0x000000);}
			for(	;i<gLCD_XSIZE*4/5;i++){GPU_WrRGB(0xFFFFFF);}
			for(	;i<gLCD_XSIZE;	i++){GPU_WrRGB(0x000000);}
		}

		for(   ;y<gLCD_YSIZE*8/8;y++)
		{
			for(i=0	;i<gLCD_XSIZE/5;	i++){GPU_WrRGB(0xFFFFFF);}
			for(	;i<gLCD_XSIZE*2/5;i++){GPU_WrRGB(0x000000);}
			for(	;i<gLCD_XSIZE*3/5;i++){GPU_WrRGB(0xFFFFFF);}
			for(	;i<gLCD_XSIZE*4/5;i++){GPU_WrRGB(0x000000);}
			for(	;i<gLCD_XSIZE;	i++){GPU_WrRGB(0xFFFFFF);}
		}
	}
}


void Img_Box(void)
{
// 	char str[128]={0};
	unsigned int x,y;
    unsigned int lx, ly;
    
    lx = gLCD_XSIZE - 1;
    ly = gLCD_YSIZE - 1;
    
	for(y = 0; y < gLCD_YSIZE; y++)
	{
		for(x = 0; x < gLCD_XSIZE; x++)
		{
			if((x==0) || (x==lx) || (y==0) || (y==ly))
			{
                GPU_WrRGB(0xffffff);
			}
			else
			{
				GPU_WrRGB(0x000000);
			}
		
		}
	}
}


void Img_Gray256_H(void)
{
	unsigned int x, y;
	u32 w;
	for(y = 0; y <gLCD_YSIZE; y++)
	{
		for(x = 0; x < gLCD_XSIZE; x++)
		{ 
			w =(x*256)/(gLCD_XSIZE); 
            w = (w<<16) | (w<<8) | w;
			GPU_WrRGB(w);
        }
	}	
}

void Img_RED256_H(void)
{
	unsigned int x, y;
	u32 w;

	for(y = 0; y <gLCD_YSIZE; y++)
	{
		for(x = 0; x < gLCD_XSIZE; x++)
		{ 
			w =(x*256)/(gLCD_XSIZE); 
            w = (w<<16);// | (w<<8) | w;
			GPU_WrRGB(w);
        }
	}	
}

void Img_GREEN256_H(void)
{
	unsigned int x, y;
	u32 w;

	for(y = 0; y <gLCD_YSIZE; y++)
	{
		for(x = 0; x < gLCD_XSIZE; x++)
		{ 
			w =(x*256)/(gLCD_XSIZE); 
            w = (w<<8);
			GPU_WrRGB(w);
        }
	}	
}

void Img_BLUE256_H(void)
{
	unsigned int x, y;
	u32 w;

	for(y = 0; y <gLCD_YSIZE; y++)
	{
		for(x = 0; x < gLCD_XSIZE; x++)
		{ 
			w =(x*256)/(gLCD_XSIZE); 
 			GPU_WrRGB(w);
        }
	}	
}

void Img_Gray256_V(void)
{
	unsigned int x, y;
	u32 w;
    
	for(y = 0; y <gLCD_YSIZE; y++)
	{	
		w=(y*256)/(gLCD_YSIZE);
        w = (w<<16) | (w<<8) | w;
		for(x = 0; x < gLCD_XSIZE; x++)
		{ 
			GPU_WrRGB(w);
        }
	}	
}

void Img_RED256_V(void)
{
	unsigned int x, y;
	u32 w;
    
	for(y = 0; y <gLCD_YSIZE; y++)
	{	
		w=(y*256)/(gLCD_YSIZE);
        w = (w<<16);// | (w<<8) | w;
		for(x = 0; x < gLCD_XSIZE; x++)
		{ 
			GPU_WrRGB(w);
        }
	}	
}

void Img_GREEN256_V(void)
{
	unsigned int x, y;
	u32 w;
    
	for(y = 0; y <gLCD_YSIZE; y++)
	{	
		w=(y*256)/(gLCD_YSIZE);
        w = (w<<8);
		for(x = 0; x < gLCD_XSIZE; x++)
		{ 
			GPU_WrRGB(w);
        }
	}	
}

void Img_BLUE256_V(void)
{
	unsigned int x, y;
	u32 w;
    
	for(y = 0; y <gLCD_YSIZE; y++)
	{	
		w=(y*256)/(gLCD_YSIZE);
		for(x = 0; x < gLCD_XSIZE; x++)
		{ 
			GPU_WrRGB(w);
        }
	}	
}


void Img_ColorBar(void)
{
    unsigned int i, j;

	for(j=0;j<gLCD_YSIZE;j++)
	{	
		for(i=0; i<gLCD_XSIZE/8; i++){ GPU_WrRGB(0xFFFFFF);}	
		for(; i<gLCD_XSIZE*2/8; i++){ GPU_WrRGB(0xFFFF00);}
		for(; i<gLCD_XSIZE*3/8; i++){ GPU_WrRGB(0x00FFFF);}
		for(; i<gLCD_XSIZE*4/8; i++){ GPU_WrRGB(0x00FF00);}
		for(; i<gLCD_XSIZE*5/8; i++){ GPU_WrRGB(0xFF00FF);}
		for(; i<gLCD_XSIZE*6/8; i++){ GPU_WrRGB(0xFF0000);}
		for(; i<gLCD_XSIZE*7/8; i++){ GPU_WrRGB(0x0000FF);}
		for(; i<gLCD_XSIZE*8/8; i++){ GPU_WrRGB(0x000000);}
		
	}
}


void Img_ColorScale_H(void)
{
	unsigned int i,j,y;
    unsigned int w;
	unsigned int x1, x2, x3, x4;

	x1 = gLCD_XSIZE*1/4;
	x2 = gLCD_XSIZE*2/4;
	x3 = gLCD_XSIZE*3/4;
	x4 = gLCD_XSIZE*4/4;


	for(y =0; y < gLCD_YSIZE/2; y++)
	{
		j=0;
		for(i = 0; i < x1; i++)
		{
		//	w=(i*255)/(x1);
			w=(j*255)/x1; j++;
            GPU_WrRGB((w<<16)|(w<<8)|w);
		}
	
		j=0;
		for(; i < x2; i++)
		{
			//w=(i*255)/(x2);
			w=(j*255)/x1; j++;
            GPU_WrRGB((w<<16)|(w<<8)|0);
		}
	
		j=0;
		for(; i < x3; i++)
		{
			//w=(i*255)/(x3);
		    w=(j*255)/x1; j++;
            GPU_WrRGB((0)|(w<<8)|w);
		}
	
		j=0;
		for(; i < x4; i++)
		{
			//w=(i*255)/(x4);
		    w=(j*255)/x1; j++;
            GPU_WrRGB((0)|(w<<8)|0);
		}
	}

	for(; y < gLCD_YSIZE; y++)
	{
		j=0;
		for(i = 0; i < x1; i++)
		{
			//w=(i*255)/(x1);
		    w=(j*255)/x1; j++;
			GPU_WrRGB((w<<16)|(0<<8)|w);
		}
	
	    j=0;
		for(; i < x2; i++)
		{
		//	w=(i*255)/(x2);
		  	w=(j*255)/x1; j++;
		    GPU_WrRGB((w<<16)|(0<<8)|0);
		}
	
	    j=0;
		for(; i < x3; i++)
		{
			//w=(i*255)/(x3);
		    w=(j*255)/x1; j++;
			GPU_WrRGB((0<<16)|(0<<8)|w);
		}
	
	    j=0;
		for(; i < x4; i++)
		{
			//w=(i*255)/(x4);
		    w=(u8)(255 - (j*255)/x1); j++;
			GPU_WrRGB((w<<16)|(w<<8)|w);
		}
	}
}

void Img_ColorScale_V(void)
{
	unsigned int x,y,i;
    unsigned char w;
	unsigned int y1, y2, y3, y4;

	y1 = gLCD_YSIZE*1/4;
	y2 = gLCD_YSIZE*2/4;
	y3 = gLCD_YSIZE*3/4;
	y4 = gLCD_YSIZE*4/4;
	i=0;
	for(y = 0; y < y1; y++)
	{
		w=(y*255)/(y1);
		for(x = 0; x < gLCD_XSIZE / 2; x++){GPU_WrRGB((w<<16)|(0<<8)|w);}	
		for(     ; x < gLCD_XSIZE;     x++){GPU_WrRGB((w<<16)|(w<<8)|w);}	
	}

	i=0;
	for(; y < y2; y++)
	{
		//w=(y*255)/(y2);
		w=(i * 255)/y1;
		i++;
		for(x = 0; x < gLCD_XSIZE / 2; x++){GPU_WrRGB((w<<16)|(0<<8)|0);}	
		for(     ; x < gLCD_XSIZE;     x++){GPU_WrRGB((w<<16)|(w<<8)|0);}	
	}

	i = 0;
	for(; y < y3; y++)
	{
		//w=(y*255)/(y3);
		w=(i * 255)/y1;	 i++;
		for(x = 0; x < gLCD_XSIZE / 2; x++){GPU_WrRGB((0<<16)|(0<<8)|w);}	
		for(     ; x < gLCD_XSIZE;     x++){GPU_WrRGB((0<<16)|(w<<8)|w);}	
	}

	i = 0;
	for(; y < y4; y++)
	{
	//	w=(y*255)/(y4);
		w=(u8)(255-(i * 255)/y1);	i++;
		for(x = 0; x < gLCD_XSIZE / 2; x++){GPU_WrRGB((w<<16)|(w<<8)|w);}	
		for(     ; x < gLCD_XSIZE;     x++){GPU_WrRGB((0<<16)|(w<<8)|0);}	
	}

}

void Img_BoxX(void)
{
	unsigned int x,y;
    unsigned int lx, ly;
    
    lx = gLCD_XSIZE - 1;
    ly = gLCD_YSIZE - 1;
    
	for(y = 0; y < gLCD_YSIZE; y++)
	{
		for(x = 0; x < gLCD_XSIZE; x++)
		{
			if((x==0) || (x==lx) || (y==0) || (y==ly))
			{
                GPU_WrRGB(0xffffff);
			}
			else
			{
				GPU_WrRGB(0x000000);
			}
		}
	}
    
    DrawLine(0,0,gLCD_XSIZE-1, gLCD_YSIZE-1,0XFFFFFF);
    DrawLine(gLCD_XSIZE-1,0,0, gLCD_YSIZE-1,0XFFFFFF);
}

/******************************* ����������� *********************************/
