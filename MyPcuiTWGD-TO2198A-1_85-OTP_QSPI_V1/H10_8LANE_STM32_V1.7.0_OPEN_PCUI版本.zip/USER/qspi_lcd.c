/********************************* SKYCODE *************************************
 * Copyright (c) 2020, ����˼�����Լ������޹�˾
 *
 * �ļ���   ��qspi_lcd.c
 * ����     ��QSPI�ӿڵ���ʾ������������
 *
 * �޸����� �� �����ٸ��˸��˼��ٱ���
 *
 * ��    �� ��V1.0.0
 * ��    �� ��ma_xiaoteng
 * ������� ��2020-6-3
 * �޸����� ��
 *******************************************************************************/

#include "sys.h"
#include "sysIO.h"
#include "sim_qspi.h"
#include <stdarg.h>
#include "qspi_lcd.h"
#include "gpu.h"
#include "sd_file.h"
#include "stdio.h"
#include "string.h"
SIM_QSPI_Adapter sg_qspi_adapter;

static u8 sg_cs = 0x01; // bit0=1 Ƭѡ��һ���ӿڣ� bit1=1 Ƭѡ�ڶ����ӿ�

static void Delay(void)
{
    Delay_us(0);
}

void QSPI_CS_Set(uint8_t level)
{
    if (level == 0) //�� ֻ���Ƹÿ��Ƶ�
    {
        if (sg_cs & 0x01)
        {
            PAout(4) = 0;
        }
    }
    else //�� ���ж�Ϊ��
    {
        //        if((sg_cs&0x01)==0){PDout(12) = 1;}
        //        if((sg_cs&0x02)==0){PBout(5) = 1;}
        //        if((sg_cs&0x04)==0){PCout(3) = 1;}
        //        if((sg_cs&0x08)==0){PCout(7) = 1;}
        PAout(4) = level;
    }

    //        PDout(12) = level;
    //        PBout(5) = level;
    //        PCout(3) = level;
    //        PCout(7) = level;
}

static void QSPI_SCK_Set(uint8_t level)
{
    PBout(6) = level;
}

/*=0 ����,=1���*/
static void QSPI_IO_Change(uint8_t io)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    if (io)
    {
        /*SI0*/
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
        GPIO_Init(GPIOB, &GPIO_InitStructure);

        /*SI1*/
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
        GPIO_Init(GPIOB, &GPIO_InitStructure);

        /*SI2*/
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
        GPIO_Init(GPIOA, &GPIO_InitStructure);

        /*SI3*/
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
        GPIO_Init(GPIOA, &GPIO_InitStructure);
    }
    else
    {
        /*SI0*/
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
        GPIO_Init(GPIOB, &GPIO_InitStructure);

        /*SI1*/
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
        GPIO_Init(GPIOB, &GPIO_InitStructure);

        /*SI2*/
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
        GPIO_Init(GPIOA, &GPIO_InitStructure);

        /*SI3*/
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
        GPIO_Init(GPIOA, &GPIO_InitStructure);
    }
}

static void QSPI_SI0_Set(uint8_t level)
{
    PBout(1) = level;
}

static void QSPI_SI1_Set(uint8_t level)
{
    PBout(0) = level;
}

static void QSPI_SI2_Set(uint8_t level)
{
    PAout(0) = level;
}

static void QSPI_SI3_Set(uint8_t level)
{
    PAout(3) = level;
}

static uint8_t QSPI_SI0_Read(void)
{
    return PBin(1);
}

static uint8_t QSPI_SI1_Read(void)
{
    return PBin(0);
}

static uint8_t QSPI_SI2_Read(void)
{
    return PAin(0);
}

static uint8_t QSPI_SI3_Read(void)
{
    return PAin(3);
}

void QSPI_LCD_IO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB | RCC_AHB1Periph_GPIOC | RCC_AHB1Periph_GPIOD | RCC_AHB1Periph_GPIOA, ENABLE);

    /*CS*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /*SCL*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    /*SI0*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    /*SI1*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    /*SI2*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /*SI3*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    sg_qspi_adapter.delay = Delay;
    sg_qspi_adapter.set_cs = QSPI_CS_Set;
    sg_qspi_adapter.set_sclk = QSPI_SCK_Set;
    sg_qspi_adapter.change_io = QSPI_IO_Change;
    sg_qspi_adapter.set_io0 = QSPI_SI0_Set;
    sg_qspi_adapter.set_io1 = QSPI_SI1_Set;
    sg_qspi_adapter.set_io2 = QSPI_SI2_Set;
    sg_qspi_adapter.set_io3 = QSPI_SI3_Set;
    sg_qspi_adapter.read_io0 = QSPI_SI0_Read;
    sg_qspi_adapter.read_io1 = QSPI_SI1_Read;
    sg_qspi_adapter.read_io2 = QSPI_SI2_Read;
    sg_qspi_adapter.read_io3 = QSPI_SI3_Read;

    QSPI_CS_Set(1);
}

static uint8_t pack_data[512];
void QSPI_LCD_PackWrite(uint8_t cmd, int data, ...)
{
    va_list param_list;
    int in_data;
    unsigned int len = 0;

    va_start(param_list, data);

    pack_data[len++] = 0x02;
    pack_data[len++] = 0x00;
    pack_data[len++] = cmd;
    pack_data[len++] = 0x00;
    pack_data[len++] = data;

    while (1)
    {
        in_data = va_arg(param_list, int);
        if (in_data == -1)
            break;
        pack_data[len++] = in_data;
    }

    uint32_t len_pack_data = sizeof(pack_data);
    if (len > len_pack_data)
        return;

    QSPI_1W_ReadWriteData(&sg_qspi_adapter, len, pack_data, 0, 0);

    va_end(param_list);
}

void QSPI_LCD_PackWrite_2(uint8_t cmd, uint16_t *data, uint32_t data_len)
{
    uint32_t len = 0;

    // for (uint32_t i = 0; i < 2; i++)
    // {
    //     // _DEBUG("%2d: R:%3d G:%3d B:%3d\r\n", i, regData[i * 3], regData[i * 3 + 1], regData[i * 3 + 2]);
    //     _DEBUG("%2d: R:%04X G:%04X B:%04X\r\n", i, data[i * 3], data[i * 3 + 1], data[i * 3 + 2]);
    // }
    // for (uint32_t i = 25; i < 27; i++)
    // {
    //     // _DEBUG("%2d: R:%3d G:%3d B:%3d\r\n", i, regData[i * 3], regData[i * 3 + 1], regData[i * 3 + 2]);
    //     _DEBUG("%2d: R:%04X G:%04X B:%04X\r\n", i, data[i * 3], data[i * 3 + 1], data[i * 3 + 2]);
    // }

    pack_data[len++] = 0x02;
    pack_data[len++] = 0x00;
    pack_data[len++] = cmd;
    pack_data[len++] = 0x00;

    uint32_t len_pack_data = sizeof(pack_data);
	
	

//    for (uint32_t i = 0; (i < data_len) && (len < len_pack_data); i++)
//    {
//        pack_data[len++] = data[i] & 0x00FF;
//        pack_data[len++] = data[i] >> 8;
//    }


for (uint32_t i = 0; (i < data_len) && (len < len_pack_data); i++)
    {
        pack_data[len++] = data[i] & 0x00FF;
//        pack_data[len++] = (data[i]&0x0700)>> 8;
		pack_data[len++] = data[i]>> 8;
    }
// _DEBUG("pack_data[%d] : 0x%02x\r\n", len - 1, pack_data[len - 1]);

// uint8_t *dat = pack_data + 4;
// printf("\r\n");
// for (int i = 0; i < 162; i++)
// {
////     printf("0x%02X,", dat[i]);
//	 SDCard_Printf("normalGammaConfig.csv","0xC5=0x%02X\r\n",dat[i]);
// }
// printf("\r\n");
// for (uint32_t i = 0; i < 2; i++)
// {
//     _DEBUG("%2d: R:%02X%02X G:%02X%02X B:%02X%02X\r\n", i, dat[i * 6], dat[i * 6 + 1], dat[i * 6 + 2], dat[i * 6 + 3], dat[i * 6 + 4], dat[i * 6 + 5]);
// }
// for (uint32_t i = 25; i < 27; i++)
// {
//     _DEBUG("%2d: R:%02X%02X G:%02X%02X B:%02X%02X\r\n", i, dat[i * 6], dat[i * 6 + 1], dat[i * 6 + 2], dat[i * 6 + 3], dat[i * 6 + 4], dat[i * 6 + 5]);
// }

    QSPI_1W_ReadWriteData(&sg_qspi_adapter, len, pack_data, 0, 0);
}

void QSPI_LCD_ReadData(uint8_t addr, unsigned int len, uint8_t *rd_data)
{
    uint8_t wr_data[4];

    wr_data[0] = 0x03;
    wr_data[1] = 0x00;
    wr_data[2] = addr;
    wr_data[3] = 0x00;

    QSPI_1W_ReadWriteData(&sg_qspi_adapter, 4, wr_data, len, rd_data);
}

/*
��ʵ��˵�������������Ϊ��Ϊ�˶�Ӧin_img2�ĳ����д������
*/
void QSPI_LCD_GotoXY(unsigned int xs, unsigned int ys, unsigned int xe, unsigned int ye)
{
    QSPI_1W_WriteByte(&sg_qspi_adapter, 0x12);
    QSPI_4W_WriteByte(&sg_qspi_adapter, 0x00);
    QSPI_4W_WriteByte(&sg_qspi_adapter, 0x2c);
    QSPI_4W_WriteByte(&sg_qspi_adapter, 0x00);
}

/*д���صĺ���*/
void QSPI_LCD_WriteRGB(uint32_t rgb) // 0xff
{

    //*********** GBRG 3553 *********//
//    QSPI_4W_WriteByte(&sg_qspi_adapter, (((rgb >> 8) & 0x1C) << 3) | ((rgb & 0XF8) >> 3));
//    QSPI_4W_WriteByte(&sg_qspi_adapter, ((rgb >> 16) & 0xF8) | (((rgb >> 8) & 0xE0) >> 5));

    //***********RGB 888 *********//
    QSPI_4W_WriteByte(&sg_qspi_adapter, rgb>>16);
    QSPI_4W_WriteByte(&sg_qspi_adapter, rgb>>8);
    QSPI_4W_WriteByte(&sg_qspi_adapter, rgb);
}

/*
 *������ : QSPI_LCD_A_CS �ȵ�
 *����   : �����ĸ�������Ƭѡ���ã��������Ͽ���CS���ţ�����дָ�� �Ͷ�ָ���Ӧ�ã���������дͼ��ʱ��Ƭѡ.
 *          ָ����֮���д ������������ĸ��ӿ���Ч��
 *����   : 1. level - CS������ĵ�ƽ
 *����   : ��
 */
void QSPI_LCD_A_CS(uint8_t level)
{
    if (level)
    {
        sg_cs &= (~0x01);
    }
    else
    {
        sg_cs |= (0x01);
    }
}

// void QSPI_LCD_B_CS(uint8_t level)
//{
//     if(level)
//     {
//         sg_cs &= (~0x02);
//     }
//     else
//     {
//         sg_cs |= (0x02);
//     }
// }

// void QSPI_LCD_C_CS(uint8_t level)
//{
//     if(level)
//     {
//         sg_cs &= (~0x04);
//     }
//     else
//     {
//         sg_cs |= (0x04);
//     }
// }

// void QSPI_LCD_D_CS(uint8_t level)
//{
//     if(level)
//     {
//         sg_cs &= (~0x08);
//     }
//     else
//     {
//         sg_cs |= (0x08);
//     }
// }

/*
 *������ : QSPI_LCD_CS_AllOut
 *����   : ����Ƭѡһ������������.����дͼ���á���д���Ҫ���������
 *����   : 1. cs_bit - ��λƬѡ ��QSPI_LCD_A_CS_BIT, QSPI_LCD_B_CS_BIT, QSPI_LCD_C_CS_BIT, QSPI_LCD_D_CS_BIT�궨�壬�ɰ�λ��
 *         2. level - CS������ĵ�ƽ
 *����   :��
 */
void QSPI_LCD_CS_AllOut(uint8_t cs_bit, uint8_t level)
{
    if (cs_bit & QSPI_LCD_A_CS_BIT)
    {
        PAout(4) = level;
    }
    //    if(cs_bit & QSPI_LCD_B_CS_BIT){PBout(5)= level;}
    //    if(cs_bit & QSPI_LCD_C_CS_BIT){PCout(3) = level;}
    //    if(cs_bit & QSPI_LCD_D_CS_BIT){PCout(7) = level;}
}

/*
 *������ : QSPI_LCD_WrByte
 *����   : дһ���ֽڵĺ��� SD�������õ�
 *����   :
 *����   :��
 */
void QSPI_LCD_WrByte(uint8_t dat)
{
    QSPI_4W_WriteByte(&sg_qspi_adapter, dat);
}
